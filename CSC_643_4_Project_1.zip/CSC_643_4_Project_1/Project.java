/**
 * \course
 * title:       CSC-643 Big Data and Web Intelligence
 * Assignment
 * number:  	Project 1
 *
 * \file:       Project.java
 * \brief:      This program connects to MongoDB on port number:27017.
 *              This code executes the queries - a) counts total number of artists in artists collection,
 *              b)finds the URL which containing the word punk in artists collection, c) most listened artist in
 *              user_artist collection, d) used mapReducer to find top 10 popular artists in user_artist collection,
 *              e)least used tag in user_taggedartist collection, f)computes the average number of tags used by
 *              each user for all artists in the user_taggedartist collection.
 *
 * \author:     Megha Ukkali-setting the connection to MongoDB using java driver 3.8 and Queries related to 3) a, b, c, d.
 *              Sagar Pandya-Queries related to 3) e, f.
 *
 * \date:       09/29/2019
 *
 * \submission
 * date:        09/30/2019
 * problem
 * number: 	    Question number: 4
 */


// import statements
import com.mongodb.*;

import com.mongodb.client.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;

import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.Arrays;
import java.util.regex.Pattern;

import static com.mongodb.client.model.Accumulators.first;
import static com.mongodb.client.model.Aggregates.*;
import static com.mongodb.client.model.Projections.*;

public class Project {

    private static MongoClient mongoClient = null;
    private static MongoDatabase database = null;

    /**
     * connectAndGetDatabase() method connects to MongoDB on port number:27017
     * This method takes one parameter.
     * @param dbName database name
     * used create() method to get connect to MongoDB on localhost port number:27017.
     * getDatabase()method is used to get access to database.
     * main() method calls connectAndGetDatabase().
     */
    public void connectAndGetDatabase(String dbName) {
        mongoClient = MongoClients.create("mongodb://localhost:27017");
        database = mongoClient.getDatabase(dbName);
    }

    /**
     * getTotalArtistCount() method gives the total count of artists.
     * getCollection()method to get access to artists collection.
     * countDocuments()method counts total count of artists and stored in count of type long.
     */
    private void getTotalArtistCount() {
        MongoCollection<Document> artistCollection = database.getCollection("artists");

        long count = artistCollection.countDocuments();
        System.out.println("The total number of artists are: " + count);
    }

    /**
     * getTotalArtistCount() method gives name of the artist and the URL which containing
     * the word punk in artists collection.
     * getCollection()method to get access to artists collection.
     * Pattern.compile()method is used to search for pattern of the word containing punk
     * and the word should be case insensitive.
     * filter selects all the documents where the name is equal to the word punk.
     * eq() method matches the name to word punk and returns the Bson type instance.
     * projection()method is used to include name and URL and excluding id field.
     * find() method is used to retrieve the documents which contains the word punk.
     * The find() method returns a FindIterable() instance.
     * Used for each loop to print the result.
     */
    private void findURLContainingWordPunk() {
        MongoCollection<Document> artistCollection = database.getCollection("artists");

        Pattern regex = Pattern.compile("punk", Pattern.CASE_INSENSITIVE);
        Bson filter = Filters.eq("name", regex);

        FindIterable<Document> result = artistCollection.find(filter).projection(fields(include("url"),
                excludeId(), include("name")));

        System.out.println("Artists Name:" + '\t'+'\t' + "URL ");
        for (Document s : result) {
            System.out.println(s.get("name") + ": " + '\t'+'\t' + s.get("url"));
        }
    }

    /**
     * findMostListenedArtist() method gives most listened artist in user_artist collection.
     * getCollection()method is used to get access to user_artists collection.
     * aggregate() method is used to group the artistID and add the weight of particular artistID.
     * Then it uses sort() to sort the weight in descending order, then it uses limit() to limit the
     * number of documents present in the collection, at last it does lookup for joining the another collection
     * for getting the name of artist. and projection used to include MostListenedArtists field excluding id field.
     * The aggregate() method returns a AggregateIterable<> instance.
     * Aggregates.sort() is used to build $sort.
     * Sorts sorts the weight in descending order and returns the Bson type instance.
     * group() method is used to group artistID and and add the weights of particular artistID by using
     * Accumulators.sum  which builds $sum.
     * group returns the Bson type instance.
     * project()method is used to include MostListenedArtists field and excluding id field.
     * This project returns Bson type instance.
     * used for each loop to print the result.
     */
    private void findMostListenedArtist() {

        MongoCollection<Document> userArtistCollection = database.getCollection("user_artists");

        Bson sort = Sorts.descending("weight");
        Bson lookup = new Document("$lookup", new Document("from", "artists").append("localField", "_id").
                append("foreignField", "id").append("as", "MostListenedArtists"));
        Bson group = group("$artistID", first("artistID", "$artistID"),
                Accumulators.sum("weight", "$weight"));
        Bson projection = project(fields(include("MostListenedArtists"), excludeId()));

        AggregateIterable<Document> result1 = userArtistCollection.aggregate(Arrays.asList(group,
                Aggregates.sort(sort), limit(1), lookup, projection));

        System.out.println("Most Listened artists: ");

        for (Document s : result1) {
            System.out.println(s.get("MostListenedArtists"));
        }
    }

    /**
     * findTopPopularArtist() method used to perform map reduce operation to find top 10 popular artists
     * in user_artist collection.
     * getCollection()method is used to get access to user_artists collection.
     * used getDB() to get access to mudb database.
     * Mongo() is used to get connection to MOngoDB on localhost on port number 27017.
     * MapReduceCommand is used to perform mapReducer. MapReduceCommand() takes the six parameter.
     * the first parameter- collection of type DBCollection- it is used as source to perform map reduce operation.
     * the second parameter- map of type String- it emits the key value pair.
     * It emits artistsID as key and userID as values.
     * the third parameter- reduce of type String- it aggregates the key value pair.
     * It aggregates keys and values, and it reduces to one object where values are specified to particular artistsID.
     * the fourth parameter- "MapReduceQuery4" of type String- it is the output collection.
     * the fifth parameter-MapReduceCommand.OutputType.REPLACE- OutputType is set to REPLACE.
     * REPLACE replaces output collection's(MapReduceQuery4)previous content with new content
     * and saves the output collection.
     * the sixth parameter is set to null.
     *
     * Then get the output collection(MapReduceQuery4) to sort, limit the documents to 10.
     * aggregate() method uses sort() to sort the value in descending order, then it uses limit() to limit the
     * number of documents present in the collection, at last it does lookup for joining the another collection
     * for getting the name,URL, pictureURL of artists.
     * and projection used to include Top10PopularArtists field and excluding id field.
     * The aggregate() method returns a AggregateIterable<> instance.
     * Aggregates.sort() is used to build $sort.
     * Sorts sorts the value in descending order and returns the Bson type instance.
     * project()method is used to include Top10PopularArtists field and excluding id field.
     * This project returns Bson type instance.
     * used for each loop to print the result.
     */
    private void findTopPopularArtist(){
        Mongo mongo = new Mongo( new DBAddress( "localhost:27017" ) );
        DB db = mongo.getDB( "mydb" );
        DBCollection collection = db.getCollection( "user_artists" );

        String map ="var mapFunction = function(){" +
                    "emit( this.artistID, { count: 1 });  };";
        String reduce = "var reduceFunction = function(artistIdKey, userIDValues) {" +
                        "var result ={count:0};" +
                        "userIDValues.forEach(function (value) {" +
                        "result.count = result.count + value.count" +
                        "}); " +
                        "return result;" +
                        "};";

         MapReduceCommand cmd = new MapReduceCommand(collection, map, reduce,
                "MapReduceQuery4", MapReduceCommand.OutputType.REPLACE, null);

        MongoCollection<Document> artistCollection = database.getCollection("MapReduceQuery4");

        Bson sort = Sorts.descending("value");
        Bson lookup = new Document("$lookup", new Document("from", "artists").append("localField", "_id").
                append("foreignField", "id").append("as", "Top10PopularArtists"));
        Bson projection = project(fields(include("Top10PopularArtists"), excludeId()));
        AggregateIterable<Document> result2 = artistCollection.aggregate(Arrays.asList(
                Aggregates.sort(sort), limit(10), lookup, projection));

        System.out.println("Most Listened artists: ");
        //for each loop to print out result.
        for (Document s : result2) {
            System.out.println(s.get("Top10PopularArtists"));
        }

    }

    /**
     * This method returns all the tags with the count of occurence of each tag
     * then we can apply a db query to find the minimum - say sort it and apply limit(1)
     */
    public void leastUsedTag() {
        Mongo mongo = new Mongo( new DBAddress( "localhost:27017" ) );
        DB db = mongo.getDB( "mydb" );
        DBCollection collection = db.getCollection( "user_taggedartist" );

        String mapFunctionCountOfTags = "function(){\n" +
                "	 emit(this.tagID, {count:1});\n" +
                "};";

        String reduceFunctionCountOfTags = "function(keyTagId, valuesUsers){\n" +
                "	var result = {count:0}\n" +
                "	valuesUsers.forEach(function(value){\n" +
                "	 result.count = result.count+1;\n" +
                "	});\n" +
                "\n" +
                "	return result;\n" +
                "};";

        // create the mapreduce command by calling map and reduce functions
        MapReduceCommand mapcmd = new MapReduceCommand(collection, mapFunctionCountOfTags, reduceFunctionCountOfTags,
                "tags_count", MapReduceCommand.OutputType.REPLACE, null);
        Bson sort = Sorts.ascending("value","_id");
        MongoCollection<Document> tagCollection = database.getCollection("tags_count");
        AggregateIterable<Document> result2 = tagCollection.aggregate( Arrays.asList(
                Aggregates.sort(sort), limit(30)));

        System.out.println("Least used tag: ");
        //for each loop to print out result.
        for (Document s : result2) {
            System.out.println(s);
        }

    }

    /**
     * This method finds the average of each user by tag on a artist level
     * it does a function map and then reduce
     * Also it has finalize step to calculate average as well.
     */
    public MapReduceOutput averageOfEachUserByTag(String dbName, String collectionName) {
        Mongo mongo = new Mongo( new DBAddress( "localhost:27017" ) );
        DB db = mongo.getDB( "mydb" );
        DBCollection coll = db.getCollection(collectionName);

        String mapFunctionUserIdWithArtistAndTagCount = "function(){\n" +
                "	var key = this.userID;\n" +
                "		    var value = {\n" +
                "		                     countArtist: 1,\n" +
                "		                     countTag:1,\n" +
                "		                     artistID: this.artistID,\n" +
                "		                     tagID:this.tagID\n" +
                "		                   };\n" +
                "		    emit(key, value);\n" +
                "		 \n" +
                "	};\n" +
                "";

        String reduceFunctionUserIdWithArtistAndTagCount = "function(userId, values){\n" +
                "	var result = {countArtist:0,countTag:0}\n" +
                "	var flags = [], output = []\n" +
                "	for (var i = 0; i < values.length; i++) {\n" +
                "		if(values[i]!=null && values[i].tagID!=null && values[i].tagID!==\"\")\n" +
                "		{\n" +
                "			result.countTag  = result.countTag + 1;\n" +
                "		}\n" +
                "	    if(flags[values[i].artistID]) continue;\n" +
                "	    flags[values[i].artistID] = true;\n" +
                "	    output.push(values[i].artistID);\n" +
                "	}\n" +
                "	result.countArtist = output.length;\n" +
                "	return result;\n" +
                "\n" +
                "};";

        String finalize = "function (key, reducedVal) {\n" +
                "    reducedVal.avg = reducedVal.countTag/reducedVal.countArtist;\n" +
                "    return reducedVal;\n" +
                "};";

        // create the mapreduce command by calling map and reduce functions
        MapReduceCommand mapcmd = new MapReduceCommand(coll, mapFunctionUserIdWithArtistAndTagCount,
                reduceFunctionUserIdWithArtistAndTagCount, null,
                MapReduceCommand.OutputType.INLINE, null);

        mapcmd.setFinalize(finalize);


        // invoke the mapreduce command
        MapReduceOutput result = coll.mapReduce(mapcmd);

        return result;
    }
    private static void printResult(MapReduceOutput mapReduceOutput) {
        System.out.println("=====================Output=====================================");
        for (DBObject o : mapReduceOutput.results()) {
            System.out.println(o.toString());
        }
        System.out.println("================================================================");
    }

    /**
     * main() calls the all the methods.
     * @param args
     * It creates object to Project() constructor.
     * connectAndGetDatabase() method connects to MongoDB on port number:27017.
     * databaseName is passed in connectAndGetDatabase().
     * This mydb is database in MOngoDB.
     * it checks whether connects to MongoDB or not if not connected it prints out the message
     * saying"Please connect to MongoDB and then fetch the collection".
     * Once it is connected to MongoDB, it calls the all the methods.
     */
    public static void main(String[] args) {
        Project project = new Project();
        String databaseName = "mydb";
        project.connectAndGetDatabase(databaseName);
        if (mongoClient != null) {
            System.out.println("==================1=========================================");
            System.out.println("a) Find the total number of artists in the database.");
            project.getTotalArtistCount();
            System.out.println("==================2=========================================");
            System.out.println("b) Find URLs of artists whose names contain the word punk.");
            project.findURLContainingWordPunk();
            System.out.println("==================3=========================================");
            System.out.println("c) Find the most listened artist(s).");
            project.findMostListenedArtist();
            System.out.println("==================4=========================================");
            System.out.println("d) Write a mapReducer to compute the top 10 popular artists");
            project.findTopPopularArtist();
            System.out.println("==================5=========================================");
            System.out.println("e) Write a mapReducer to find the least used tag.");
            project.leastUsedTag();
            System.out.println("f)Write a mapReducer to compute the average number oftags used by" +
                                   "each user for all artists.");
            System.out.println("==================6=========================================");
            MapReduceOutput mapReduceOutputUsers = project.averageOfEachUserByTag("assignment",
                    "user_taggedartists");
            printResult(mapReduceOutputUsers);
        } else {
            System.out.println("Please connect to MongoDB and then fetch the collection");
        }
    }


}
