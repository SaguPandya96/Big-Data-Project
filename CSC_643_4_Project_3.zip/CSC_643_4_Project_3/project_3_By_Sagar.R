#Name:                    Megha Ukkali,
#                         Sagar Pandya 
#Course number and title: CSC-643 BigData and Web Intelligence
#Assignment number:       Project 3
#Date:                    11/25/2019
#Problem number:          1,2,3
#Solution num:            2

# Installing and loading the packages
install.packages('corrplot')

library(sparklyr)
library(dplyr)

#Initializing spark 2.1.0 and now 2.2.0
spark_install(version = "2.2.0")
sc <- spark_connect(master = "local")

# Loading the data
phising_data <- read.csv('C:/Users/Sony/Downloads/PhishingData.csv')

# Exploratory Data Analysis
# All the variables in the this dataset are categorical variables and they are 
# encoded with nunmbers to represent different categories
summary(phising_data)
str(phising_data)


# Data Preprocessing
# 1. There are no missing values in the dataset
# 2. Since there are '-1' values, we need to change them to a different positive number. 
#    Decision won't accept negative values in the feature set of the modelling so we are converting -1 to 2.

phising_data$SFH[phising_data$SFH == -1] <- 2
phising_data$popUpWidnow[phising_data$popUpWidnow == -1] <- 2
phising_data$SSLfinal_State[phising_data$SSLfinal_State == -1] <- 2
phising_data$Request_URL[phising_data$Request_URL == -1] <- 2
phising_data$URL_of_Anchor[phising_data$URL_of_Anchor == -1] <- 2
phising_data$web_traffic[phising_data$web_traffic == -1] <- 2
phising_data$URL_Length[phising_data$URL_Length == -1] <- 2
phising_data$age_of_domain[phising_data$age_of_domain == -1] <- 2
phising_data$Result[phising_data$Result == -1] <-2

# Loading the R dataframe as a Spark table - This step is needed for modelling the data using Sparklyr
phising_tbl <- sdf_copy_to(sc, phising_data, name = "phising_data_tbl", overwrite = TRUE)
  



# Spliting the dataset into train and test
partitions <- phising_tbl %>%
    sdf_random_split(training = 0.7, test = 0.3, seed = 1111)
phising_training <- partitions$train
phising_test <- partitions$test
  
# Correlation Matrix between all the variables

corrs <- phising_training %>% 
  mutate(phising_state = if_else(Result == -1, "Yes", 0)) %>% 
  select_if(is.numeric) %>% 
  filter_all(all_vars(!is.na(.))) %>% 
  ml_corr(method = "spearman")

corrs

library(corrplot)

rownames(corrs) <- colnames(corrs)
p <- corrplot(as.matrix(corrs))
p

# Model Training -
# A decision tree model is trained with parameters max_depth=10, max_bins = 40, min_instances_per_node = 3
# This set of parameters gave an acurracy of around 87%
dt_model <- ml_decision_tree_classifier(phising_training,Result ~ .,max_depth = 10,
                                        max_bins = 40, min_instances_per_node = 3, min_info_gain = 0,
                                        impurity = "gini")
dt_model <- phising_training %>%
  ml_decision_tree(Result ~ .)

# Model Prediction 
# We are predicting the model results using the Decision Model
pred <- ml_predict(dt_model,phising_test)
  
# Model Evaluation - Classification Accuracy - 87.34%
ml_multiclass_classification_evaluator(pred)


# Modelling using C50

library(C50)
library(ggpubr)
theme_set(theme_pubr())


# Exploratory Data Analysis Using ggplot and SparklyR table

x_labels <- c("Legitimate", "Phish")
phising_tbl %>% ggplot(aes(x = as.factor(age_of_domain))) + 
  geom_bar(fill = "#0073C2FF", alpha =0.6) + scale_x_discrete(labels= x_labels) + 
  xlab('Type of Website') 

x_labels <- c("False","True")
phising_tbl %>% ggplot(aes(as.factor(having_IP_Address))) +
  geom_bar(fill = "#EFC000FF", alpha =0.6) + xlab("Has an IP Address?")+theme_pubclean()

x_labels <- c("Suspicious", "Legitimate","Phish")
phising_tbl %>% ggplot(aes(as.factor(URL_Length))) + geom_bar(fill = "#00AFBB", alpha =0.6) +
  scale_x_discrete(labels = x_labels) +theme_pubclean()

x_labels <- c("Suspicious", "Legitimate","Phish")

phising_tbl %>% ggplot(aes(as.factor(web_traffic))) + geom_bar(fill = "#FF6666", alpha =0.6) +
  scale_x_discrete(labels=x_labels) + xlab("Web Traffic") + theme_pubclean()

 
x_labels <- c("Suspicious", "Legitimate","Phish")

phising_tbl %>% ggplot(aes(as.factor(SFH))) + geom_bar(fill = "#0073C2FF", alpha =0.6) +
  scale_x_discrete(labels=x_labels) + xlab("SFH") + theme_pubclean()

x_labels <- c("Suspicious", "Legitimate","Phish")

phising_tbl %>% ggplot(aes(as.factor(popUpWindow))) + geom_bar(fill = "#FC4E07", alpha =0.6) +
  scale_x_discrete(labels=x_labels) + xlab("Pop Up Window") + theme_pubclean()

x_labels <- c("Suspicious", "Legitimate","Phish")

phising_tbl %>% ggplot(aes(as.factor(SSLfinal_State))) + geom_bar(fill = "#EFC000FF", alpha =0.6) +
  scale_x_discrete(labels=x_labels) + xlab("SSL Final State") + theme_pubclean()


x_labels <- c("Suspicious", "Legitimate","Phish")

phising_tbl %>% ggplot(aes(as.factor(Request_URL))) + geom_bar(fill = "#0073C2FF", alpha =0.6) +
  scale_x_discrete(labels=x_labels) + xlab("Request URL") + theme_pubclean()

phising_tbl %>% ggplot(aes(as.factor(URL_of_Anchor))) + geom_bar(fill = "#0073C2FF", alpha =0.6) +
  scale_x_discrete(labels=x_labels) + xlab("Request URL") + theme_pubclean()




# Train and Test Split
train_set <- phising_data[1:947,]
test_set <- phising_data[948:1353,]
train_input <- train_set[,1:9]
train_output <- train_set[,10]
test_input <- test_set[,1:9]
test_output <- test_set[,10]



model1 <- C5.0(train_input, as.factor(train_output), control = C5.0Control(noGlobalPruning = TRUE,minCases=1))
plot(model1, main="C5.0 Decision Tree - Unpruned, min=1")


model2 <- C5.0(train_input, as.factor(train_output), control = C5.0Control(noGlobalPruning = FALSE))
plot(model2, main="C5.0 Decision Tree - Pruned")
    
model1

# Relationship between the variables and the target in decision trees
model2
summary(model2)

predict(model2,test_set,type="class")

rules_model <-C5.0(train_input,as.factor(train_output), rules=TRUE)
summary(rules_model)
